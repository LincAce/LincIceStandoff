# GodsTeam Mod Menu design

![](https://i.imgur.com/QozJ8FA.gif)

We are not GodsTeam nor support them. But my friend asked me to design this menu for him long time ago

This project is based on old commit of LGL Mod Menu, you know right? https://github.com/LGLTeam/Android-Mod-Menu/tree/3f794e069ea76b8fbba6bdc2d2d467c7d9421c03

About `SliderString`, you can show text in the sliders instead of number. Make sure to do if-else-statement check

This project will not be maintained, You must do everything yourself.

I don't accept request designing other menus at this time. How about you try to do it yourself? :P
