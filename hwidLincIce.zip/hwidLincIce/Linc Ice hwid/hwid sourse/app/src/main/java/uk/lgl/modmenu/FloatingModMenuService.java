/*
 * Credit:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */

package uk.lgl.modmenu;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TimeAnimator;
import android.animation.ValueAnimator;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import static uk.lgl.modmenu.StaticActivity.cacheDir;
import android.widget.RadioGroup.LayoutParams;

public class FloatingModMenuService extends Service {
    private MediaPlayer FXPlayer;
    public View mFloatingView;
    private Button kill;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    //private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    private LinearLayout Btns;
    private AlertDialog alert;

    public static boolean check;

    private native String Title();

    private native String Icon();

    private native boolean EnableSounds();

    float ICON_ALPHA = 1.0f;

    private native int IconSize();

    public native void Changes(int feature, int value);

    private native String SliderString(int feature, int value);

    private native String[] getFeatureList();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
		if (check) {
        initFloating();
        }
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                Thread();
                handler.postDelayed(this, 1000);
            }
        });
    }

    //Here we write the code for our Menu
    private void initFloating() {
        FrameLayout frameLayout = new FrameLayout(getBaseContext());
        RelativeLayout relativeLayout = new RelativeLayout(getBaseContext());
        // rootFrame = new FrameLayout(getBaseContext()); // Global markup
        // mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        patches = new LinearLayout(getBaseContext());
        Btns = new LinearLayout(getBaseContext());
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        relativeLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        ImageView imageView = new ImageView(getBaseContext());
        startimage = imageView;

        imageView.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        // int applyDimension = (int) TypedValue.applyDimension(1, (float) 60, getResources().getDisplayMetrics());
        view1 = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)

        //********** Gradients **********
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        String str = "#a9333333";
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setStroke(3, Color.parseColor(str));
        gradientDrawable.setCornerRadius(8.0f);

        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable2.setColor(-1);
        gradientDrawable2.setStroke(3, -1);
        gradientDrawable2.setCornerRadius(8.0f);

        GradientDrawable gradientDrawable3 = new GradientDrawable();
        gradientDrawable3.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable3.setColor(Color.parseColor("#00000000"));
        gradientDrawable3.setStroke(0, -1);
        gradientDrawable3.setCornerRadius(8.0f);

        GradientDrawable gradientDrawable4 = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable4.setColor(Color.parseColor(str));
		String HUINA = "#00000000";
        gradientDrawable4.setStroke(3, Color.parseColor("#FF2D3133"));
        gradientDrawable4.setCornerRadius(50.0f);

		GradientDrawable gradientDrawable5 = new GradientDrawable();
        gradientDrawable5.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable5.setColor(Color.parseColor("#00000000"));
        gradientDrawable5.setStroke(0, 1);
        gradientDrawable5.setCornerRadius(0.0f);


        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        // mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);

        //********** Mod menu image **********
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
        //********** Mod menu box **********
        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(-16777216);
        mExpanded.setBackground(gradientDrawable4);
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(0, 0, 0, 35);
		mExpanded.setLayoutParams(new LinearLayout.LayoutParams(450, -2)); //-1
        ScrollView scrollView = new ScrollView(getBaseContext());
		scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 450));
		
        //********** Feature list **********
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setBackgroundColor(Color.parseColor("#000000"));
        patches.setPadding(0, 0, 0, 0);
        patches.setBackgroundColor(Color.parseColor("#00000000"));
        patches.setOrientation(LinearLayout.VERTICAL);

        this.Btns.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.Btns.setBackgroundColor(0);
        this.Btns.setGravity(5);
        this.Btns.setPadding(0, 0, 5, 0);
        this.Btns.setOrientation(LinearLayout.HORIZONTAL);
		
        //********** Title text **********
        //********** Title text ******

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='Pompadur'>Modded by Wenry</font>"));
        if (dpi() > 400)
            textView.setTextSize(16.0f);
        else
            textView.setTextSize(19.0f);
        textView.setGravity(17);
        textView.setPadding(0, 8, 0, 8);
		textView.setTextColor(Color.WHITE);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;

		final ArgbEvaluator evaluator = new ArgbEvaluator();
        ValueAnimator animator = new ValueAnimator();
        animator.setIntValues(Color.GREEN, Color.LTGRAY, Color.BLUE, Color.RED, Color.MAGENTA, Color.YELLOW, Color.CYAN, Color.YELLOW);
        animator.setEvaluator(evaluator);
        animator.setDuration(3500);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

				@Override
				public void onAnimationUpdate(ValueAnimator animator) {
					textView.setTextColor((int) animator.getAnimatedValue());
				}

			});
        animator.start();




        textView.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					mCollapsed.setVisibility(View.VISIBLE);
					mCollapsed.setAlpha(ICON_ALPHA);
					mExpanded.setVisibility(View.GONE);

				}
			});
        textView.setOnLongClickListener(new View.OnLongClickListener() {
				public boolean onLongClick(View view) {
					mCollapsed.setVisibility(View.VISIBLE);
					mCollapsed.setAlpha(0);
					mExpanded.setVisibility(View.GONE);
					Toast.makeText(view.getContext(), "Icon hidden. Remember the hidden icon position", Toast.LENGTH_LONG).show();

					return true;
				}
			});
        //textView.setLayoutParams(layoutParams2);

        //********** Close button ******

        //********** Add views **********
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        frameLayout.addView(relativeLayout);
        relativeLayout.addView(this.mCollapsed);
        relativeLayout.addView(this.mExpanded);
        mCollapsed.addView(startimage);
        mExpanded.addView(textView);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        this.mExpanded.addView(this.Btns);

        this.mFloatingView = frameLayout;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        params.gravity = 8388659;
        params.x = 0;
        params.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        frameLayout.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }
	
    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private boolean hide = false;

    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});


    }

    private void CreateMenuList() {
		if (check) {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(feature, split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                    public void OnWrite(int i) {
                        Changes(feature, i);
                    }
                });
            } else if (str.contains("Button_")) {
                addButton(str.replace("Button_", ""), new InterfaceBtn() {
                    public void OnWrite() {
                        Changes(feature, 0);
                    }
                });
            } else if (str.contains("ButtonHide_")) {
                addButton(str.replace("ButtonHide_", ""), new InterfaceBtn() {
                    public void OnWrite() {
                        hide = !hide;
                    }
                });
            } else if (str.contains("Text_")) {
                addText(str.replace("Text_", ""));
            }
        }
		}
    }

    public TextView addText(String str) {
        TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<u><b>" + str + "</u></b>"));
        textView.setTextColor(Color.parseColor("#ffffffff"));
        textView.setTextSize(11.0f);
        textView.setGravity(3);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        textView.setPadding(5, 0, 0, 0);
        this.patches.addView(textView);
        return textView;
    }

    public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        String str2 = "#ffffffff";
        gradientDrawable.setColor(Color.parseColor(str2));
        gradientDrawable.setStroke(3, Color.parseColor(str2));
        gradientDrawable.setCornerRadius(8.0f);
        final GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable2.setColor(0);
        gradientDrawable2.setStroke(3, Color.parseColor(str2));
        gradientDrawable2.setCornerRadius(8.0f);

        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 0, 0, 0);
        button.setText(feature + "");
        button.setTextColor(Color.parseColor("#ffffffff"));
        button.setTextSize(12.0f);
        button.setAllCaps(false);
        button.setBackgroundColor(Color.parseColor("#00000000"));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, dp(40));
        button.setPadding(0, 0, 0, 0);
        layoutParams2.bottomMargin = 0;
        button.setLayoutParams(layoutParams2);
        final String feature2 = feature;
        button.setOnClickListener(new View.OnClickListener() {
				private boolean isActive = true;

				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (isActive) {

						button.setText(feature2 + "");
						button.setTextSize(13.0f);
						button.setBackgroundColor(Color.parseColor("#3effffff"));
						isActive = false;
						return;
					}

					button.setText(feature2 + "");
					button.setTextSize(12.0f);
					button.setBackgroundColor(Color.parseColor("#00000000"));
					isActive = true;
				}
			});
        patches.addView(button);
    }

    private void addSeekBar(final int featurenum, final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);

        //Textview
        final TextView textView = new TextView(this);
        String str = SliderString(featurenum, 0);


        if (str != null) //Show text progress instead number
            textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + " : " + str + "</b></font>"));
        else  //If string is null, show number instead
            textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + " : " + prog + "</b></font>"));
        textView.setTextColor(Color.parseColor("#ffffffff"));
        textView.setTextSize(11.0f);
        textView.setGravity(3);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        textView.setPadding(5, 0, 0, 0);

        //Seekbar
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#ffffffff"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("#ffffffff"), PorterDuff.Mode.MULTIPLY);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.bottomMargin = 10;
        seekBar.setLayoutParams(layoutParams2);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					if (l < i) {
						playSound(Uri.fromFile(new File(cacheDir + "SliderIncrease.ogg")));
					} else {
						playSound(Uri.fromFile(new File(cacheDir + "SliderDecrease.ogg")));
					}
					l = i;
					String str = SliderString(featurenum, i);

					interInt.OnWrite(i);
					TextView textView = textView2;

					if (str != null)
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + " : " + str + "</b></font>"));
					else
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + " : " + i + "</b></font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

    boolean delayed;

    public void playSound(Uri uri) {
        if (EnableSounds()) {
            if (!delayed) {
                delayed = true;
                if (FXPlayer != null) {
                    FXPlayer.stop();
                    FXPlayer.release();
                }
                FXPlayer = MediaPlayer.create(this, uri);
                if (FXPlayer != null)
                    //Volume reduced so sounds are not too loud
                    FXPlayer.setVolume(0.4f, 0.4f);
                FXPlayer.start();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        delayed = false;
                    }
                }, 100);
            }
        }
    }

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dpi() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        return (int) (metrics.density * 160f);
    }

    private int dp(int i) {
        if (dpi() > 400)
            return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics()) - 20;
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

    /* access modifiers changed from: private */
    public void Thread() {
        if (mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            mFloatingView.setVisibility(View.INVISIBLE);
        } else {
			if (check) {
            mFloatingView.setVisibility(View.VISIBLE);
			}
			else
				{
			mFloatingView.setVisibility(View.INVISIBLE);
		    }
        }
    }

    static void setCornerRadius(GradientDrawable gradientDrawable, float f) {
        gradientDrawable.setCornerRadius(f);
    }

    static void setCornerRadius(GradientDrawable gradientDrawable, float f, float f2, float f3, float f4) {
        gradientDrawable.setCornerRadii(new float[]{f, f, f2, f2, f3, f3, f4, f4});
    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}
